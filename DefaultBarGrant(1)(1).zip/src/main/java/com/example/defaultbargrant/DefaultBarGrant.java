package com.example.defaultbargrant;

import org.bukkit.Bukkit;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

public class DefaultBarGrant extends JavaPlugin {
    @Override
    public void onEnable() {
        Permission barPerm = new Permission("gamblebar.use", PermissionDefault.TRUE);
        if (Bukkit.getPluginManager().getPermission("gamblebar.use") == null) {
            Bukkit.getPluginManager().addPermission(barPerm);
        }
        getLogger().info("DefaultBarGrant enabled - gamblebar.use granted to all players by default.");
    }
}
